"""
假设project名为: example_package_YOUR_USERNAME_HERE
目录结构为：
packaging_tutorial/
└── src/
    └── example_package_twipsy/ # 该文件夹名应为project名
        ├── __init__.py # 该文件表明父目录为一个package
        └── example.py # 普通的实现代码逻辑的py文件
"""


def add_one(number):
    return number + 1
    